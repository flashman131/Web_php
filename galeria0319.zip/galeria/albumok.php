<?php
require_once 'config/init.php';
menu("");
not_logged();
echo '<div class="row">';

$sql = "SELECT * FROM album WHERE tulajdonosId = {$_SESSION['userid']} OR privat = 0";
$res = $conn -> query($sql);
if (!$res){
    die( "Hiba a lekérdezés során!");
}
while ($row = $res -> fetch_assoc()){
    $album = file_get_contents("html/album_kartya.html");
    $album = str_replace("::albumhivatkozas::","album_kepei.php?albumid=".$row['id'],$album);
    $album = str_replace("::albumid::",$row['id'],$album);
    $album = str_replace("::albumkep::","album.png",$album);
    $album = str_replace("::albumnev::",$row['nev'],$album);
    $album = str_replace("::albumdatum::",$row['datum'],$album);
echo $album;
}
echo '</div>';
print_html("html/footer.html");
