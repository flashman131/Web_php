<?php
$host = "localhost";
$user = "galeria";
$pwd = "galeriaUser";
$db = "galeria";

$conn = new mysqli($host, $user, $pwd, $db);

if ($conn -> connect_errno){
    die("Hiba a csatlakozáskor!".$conn -> connect_error);
}
$conn -> set_charset("utf8");
