<?php

function is_logged() {
    if (isset($_SESSION['userid'])) {
        return true;
    } else {
        return false;
    }
}

function not_logged(){
    if (!is_logged()){
        $_SESSION['logout_err'] = true;
        //dd("location: ".DOC_ROOT."index.php");
        header("location: ".DOC_ROOT."index.php");
    }
}

function dd($var) {
    var_dump($var);
    die();
}

function mappanevetVisszaad($conn, $id) {
    $sql = "SELECT mappanev FROM album WHERE id = ?;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if (!$stmt->errno) {
        $stmt->bind_result($mappanev);
        $stmt->fetch();
        $stmt->close();
        return $mappanev;
    } else {
        $stmt->close();
        return "Hiba a mappa nevének lekérdezése során!";
    }
}

function print_html($html) {
    echo file_get_contents($html);
}

function menu($js){
    $menu = file_get_contents("html/header.html");
    $menu = str_replace("::javascript::",$js,$menu);
    if (is_logged()) {
        $menu = str_replace("::logout::", file_get_contents("html/logout_btn.html"), $menu);
        echo $menu;
    } else {
        $menu = str_replace("::logout::", "", $menu); //mit, mire, miben
        echo $menu;
    }
}