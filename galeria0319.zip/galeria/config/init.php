<?php
session_start();
define("DOC_ROOT",$_SERVER['DOCUMENT_ROOT']."/galeria/");

require_once DOC_ROOT.'config/connect.php';
require_once DOC_ROOT.'config/functions.php';

