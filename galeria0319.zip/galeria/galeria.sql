-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2019. Már 12. 14:23
-- Kiszolgáló verziója: 10.1.30-MariaDB
-- PHP verzió: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `galeria`
--
CREATE DATABASE IF NOT EXISTS `galeria` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `galeria`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `album`
--

CREATE TABLE `album` (
  `id` int(11) NOT NULL,
  `nev` varchar(64) COLLATE utf8_hungarian_ci NOT NULL,
  `mappanev` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `tulajdonosId` int(11) NOT NULL,
  `privat` tinyint(1) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `album`
--

INSERT INTO `album` (`id`, `nev`, `mappanev`, `tulajdonosId`, `privat`, `datum`) VALUES
(1, 'album', 'albummappa', 1, 0, '2019-02-12'),
(2, 'ujalbum', 'ujalbum', 1, 1, '2019-02-27'),
(3, 'business', 'business', 1, 0, '2019-03-11'),
(4, 'üzleti', 'uzleti', 1, 1, '2019-03-11'),
(5, 'tesztalbum', 'tesztalbum', 2, 1, '2019-03-12');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kepek`
--

CREATE TABLE `kepek` (
  `id` int(11) NOT NULL,
  `feltoltoId` int(11) NOT NULL,
  `fajlnev` varchar(128) COLLATE utf8_hungarian_ci NOT NULL,
  `albumId` int(11) NOT NULL,
  `datum` date NOT NULL,
  `fajlhelye` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `kepek`
--

INSERT INTO `kepek` (`id`, `feltoltoId`, `fajlnev`, `albumId`, `datum`, `fajlhelye`) VALUES
(1, 1, 'viz.jpeg', 1, '2019-02-12', 'ujalbum'),
(2, 1, 'pexels-photo-990818.jpeg', 4, '2019-03-12', 'uzleti'),
(3, 1, 'pexels-photo-830891.jpeg', 4, '2019-03-12', 'uzleti'),
(4, 2, 'pexels-photo-830891.jpeg', 5, '2019-03-12', 'tesztalbum');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `felhasznalonev` varchar(25) COLLATE utf8_hungarian_ci NOT NULL,
  `teljesnev` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `user`
--

INSERT INTO `user` (`id`, `felhasznalonev`, `teljesnev`, `jelszo`) VALUES
(1, 'laci', 'Marosi Laci', 'laci'),
(2, 'teszt', 'Teszt Elek', 'teszt');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `kepek`
--
ALTER TABLE `kepek`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `album`
--
ALTER TABLE `album`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `kepek`
--
ALTER TABLE `kepek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
