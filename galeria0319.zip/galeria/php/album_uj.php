<?php

$form = file_get_contents("../html/ujalbum_form.html");
echo $form;

