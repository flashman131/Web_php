<?php
require_once('../config/connect.php');
if (isset($_POST['modosit'])){
    $albumNev = $_POST['albumnev'];
    $privat = $_POST['privat'];
    $albumId = $_POST['albumid'];
    $sql = "UPDATE album SET nev = ?, privat = ? WHERE id = ?;";
    $stmt = $conn -> prepare($sql);
    $stmt -> bind_param("sii", $albumNev, $privat, $albumId);
    $stmt -> execute();
    
    if ($stmt -> errno == 0){
        echo "A mappa adatai frissítésre kerültek";
    }
    
    $stmt -> close();
    $conn -> close();
}

