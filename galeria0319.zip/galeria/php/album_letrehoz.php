<?php
require_once('../config/init.php');
if (!is_logged()){
    die("Album létrehozásához be kell jelentkezni!");
}
//echo "Sikeres POST";
if (isset($_POST['letrehoz'])){
    //echo "Sikeres POST";
    $albumNev = $_POST['albumnev'];
    $mappaNev = $_POST['mappanev'];
    $privat = $_POST['privat'];
    
    $sql = "INSERT INTO album (nev, mappanev, tulajdonosId, privat, datum) VALUES (?, ?, ?, ?, CURDATE());";
    $stmt = $conn -> prepare($sql);
    $stmt -> bind_param("ssii", $albumNev, $mappaNev, $_SESSION['userid'], $privat);
    $stmt -> execute();
    if ($stmt -> errno) {
        echo "Hiba! Létező album- vagy mappanév.";
    } else {
        echo $albumNev." nevű album mentése sikeres!";
        mkdir("../images/".$mappaNev);
    }
$stmt -> close();
}

$conn -> close();
