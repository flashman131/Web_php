$(document).ready(function(){
    $.get("php/albumok.php",function(valasz){
        $("#albumok").html(valasz);
    });
    $(document).on("click",".enter",function(){
        let user = $("#user").val();
        let pwd = $("#pwd").val();
        user = user.trim();
        pwd = pwd.trim();
        if (user.length > 0 && pwd.length > 0){
            $.ajax({
                url: "php/login.php",
                method: "POST",
                data: {user : user, pwd: pwd, enter: 1},
                success: function(valasz){
                    location.reload();
                },
                error: function(status){}
            });
        }
        
    });
});


