$(document).ready(function(){
    init();
            
    $("#letezoAlbum").click(function(e){
         e.preventDefault();
    });
    
    $(document).on("change","#album",function(){
        let albumId = $(this).val();
        console.log("albumid:"+albumId);
        console.log(albumId == 0);
        if (albumId == 0){
            //új albumot hozunk létre
            ujAlbumForm();
            console.log("ujalbum megjelenik");
        } else{
            //kellenek a jelenlegi adatok
            albumAdatitOlvas(albumId);
        }
    });
    
    $(document).on("click","[name = modosit]",function(){
        let albumNev = $("[name = albumnev]").val();
        console.log("albumnev: "+albumNev);
        let privat = $("[name = privat]").val();
        let albumId = $("[name = albumid]").val();
        let modosit = 1;
        $.ajax({
            url: "php/album_modosit.php",
            method: "POST",
            data:{"modosit" : 1,
                "albumnev" : albumNev,
                "privat" : privat,
                "albumid" : albumId},
            success: function(valasz){
                alert(valasz);
            },
            error: function(textStatus){
                //Hiba esetén
                //console.log(textStatus);
            }

        });
    });
    //új album létrehozása
    $(document).on("click", "[name=letrehoz]", function(event){
        event.preventDefault();
        let albumNev = $("[name=albumNev]").val();
        let mappaNev = $("[name=mappaNev]").val();
        let privat = $("[name=privat]").val();
        if (privat) { privat = 1 };
        console.log(albumNev, privat, mappaNev );
        $.ajax({
            url: "php/album_letrehoz.php",
            method: "post",
            data: {"albumnev" : albumNev,
                "privat" : privat,
                "mappanev" : mappaNev,
                "letrehoz" : 1},
            success: function(valasz){
                alert(valasz);
                location.reload();
            },
            error: function(){
                
            }
        });
    }); //létrehozás vége

    
   
}); // document.ready vége

function ujAlbumForm(){
    $.get("php/album_uj.php",
        function(valasz){
            $("#albumform").html(valasz);
        }
    )
}


function init(){
    $.get("php/album_valaszto.php",
        function(valasz){
            $("#albumvalaszto").html(valasz);
        }
    )
    ujAlbumForm();
}

function albumAdatitOlvas(albumId){
    $.ajax({
            url: "php/album_adatai.php",
            method: "POST",
            data: {"albumid" : albumId},
            success: function(valasz){
                $('#albumform').html(valasz);
            },
            error: function(textStatus){
                console.log(textStatus);
            }
    });
}

