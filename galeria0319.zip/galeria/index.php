<?php
require_once 'config/init.php';

menu("feltolt.js");

if (is_logged()) {
    print_html("html/feltolt_form.html");
} else {
    print_html("html/login_form.html");
}

if (isset($_SESSION['logout_err']) && ($_SESSION['logout_err'])){
    print_html("html/nincs_belepve.html");
    unset($_SESSION['logout_err']);
}

print_html("html/footer.html");