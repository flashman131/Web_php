<?php

require_once 'config/init.php';


print_html("html/header.html");
print_html("html/menu.html");


print_html("html/login.html");

print_html("html/footer.html");

