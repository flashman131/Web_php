<?php
require_once 'config/init.php';
is_logged();

print_html("html/header.html");
print_html("html/menu.html");
print_html("html/feltolt.html");
print_html("html/footer.html");


