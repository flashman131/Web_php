<?php

require_once 'config/init.php';


menu("album.js");
not_logged();

echo '<div id="albumvalaszto">
                
            </div>
            <div id="albumform">
                
            </div>';


print_html("html/footer.html");