<?php
require_once '../config/init.php';
if (isset($_POST['enter'])){
    $user = $_POST['user'];
    $pwd = $_POST['pwd'];
    $sql = "SELECT * FROM user WHERE felhasznalonev = ? AND jelszo = ?";
    $stmt = $conn -> prepare($sql);
    $stmt -> bind_param("ss",$user, $pwd);
    $stmt -> execute();
    $stmt -> store_result();
    
    if ($stmt -> num_rows == 1){
        //Belépett
        $stmt -> bind_result($id, $fnev, $tnev, $jelszo);
        $stmt -> fetch();
        $_SESSION['userid'] = $id;
    } else {
        //Sikertelen belépés
        echo "Helytelen felhasználónév vagy jelszó!";
    }
    $stmt ->close();
}
$conn -> close();