<?php
 require_once('../config/connect.php');
 $sql = "SELECT * FROM album;";
 $res = $conn -> query($sql);
 if ($res -> num_rows == 0){
     //nincs album a rendszerben
     echo "Először rögzítsen egy albumot!";
 } else {
     //albumok listája
     $html = "<select class='form-control' name='album' id='album'>"
             . "<option value='0'>Új album felvitele </option>";
     while ($row = $res -> fetch_assoc()){
         $html .= "<option value='{$row['id']}'>{$row['nev']} </option>";
     }
     $html .= "</select>";
 }
echo $html;
$conn -> close();

