<?php
require_once('../config/connect.php');
if (!isset($_POST['albumid'])){
    die("Nincs kiválasztott album!");
}
$albumId = $_POST['albumid'];
$stmt = $conn -> prepare("SELECT * FROM album WHERE id = ?;");
$stmt -> bind_param("i", $albumId);
$stmt -> execute();

//id, nev, mappanev, tulajdonosId, privat, datum
$stmt -> bind_result($id, $nev, $mappa, $tulaj, $privat, $datum);
$html ="<form>";
while ($stmt -> fetch()){
    $html .= "<input type='text' name='albumnev' placeholder='{$nev}' value='{$nev}'>"
    . "<p>{$mappa}</p>"
    . "Privát album: <input type='checkbox' name='privat'><br>"
    . "<input type='hidden' name ='albumid' value='{$id}'> "
    . "<input type='submit' name='modosit' value='Módosít'>";
}
$html .= "</from>";
echo $html;
$stmt -> close();
$conn -> close();
