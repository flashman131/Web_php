<?php
require_once'../config/init.php';
if (!is_logged()){
    die("A funkció használatához be kell jelentkezni!");
    header("Location: ../index.php");
}
if (!isset($_POST['upload'])){
    die("Nem kattintottál a feltöltés gombra!" );
}
$albumId = $_POST['album'];
$imgLeiras = $_POST['leiras'];
if (!isset($_FILES['fajl'])){
    die("Hiba a feltöltés során!");
    header("Location: ../index.php");
}
$mappaNev = mappanevetVisszaad($conn, $albumId);
//dd($mappaNev);
$imgName = $_FILES['fajl']['name'];
$imgType = $_FILES['fajl']['type'];
$imgTmpName = $_FILES['fajl']['tmp_name'];
$imgSize = $_FILES['fajl']['size'];
$uploadError = $_FILES['fajl']['error'];
$imgFormat = array("image/jpeg", "image/png");

if (in_array($imgType, $imgFormat) && $imgSize < 16000000){
    if (!file_exists("J:\htdocs\galeria\images\\".$imgName)) {
        move_uploaded_file($imgTmpName, "../images/".$mappaNev."/".$imgName);
        $sql = "INSERT INTO kepek (feltoltoId, fajlnev, albumId,datum, fajlhelye, leiras) VALUES (?,?,?,CURRENT_DATE(),?,?)";
        $stmt = $conn -> prepare($sql);
        //dd($stmt);
        $stmt -> bind_param("isiss", $_SESSION['userid'], $imgName, $albumId, $mappaNev, $imgLeiras);
        $stmt -> execute();
        
    } else {
        echo "Már létezik ilyen nevű fájl!";
    }
} else {
    echo "Nem engedélyezett fájltípus, vagy túl nagy néretű!";
}
header("Location: ../index.php");