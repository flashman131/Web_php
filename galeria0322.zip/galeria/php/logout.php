<?php
require_once '../config/init.php';
unset($_SESSION["userid"]);
//session_destroy;
header("Location: ../index.php");
