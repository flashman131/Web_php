<?php
require_once 'config/init.php';
menu("");
if (!is_logged()){
    die("A tartalom megtekintéséhez be kell jelentkezni!");
}
if (isset($_GET['albumid'])){
   $albumid = $_GET['albumid'];
   $sql = "SELECT fajlnev, fajlhelye, leiras FROM kepek WHERE albumId= $albumid";
   $result = $conn -> query($sql);
   if(!$result){
       die("Sikertelen lekérdezés");
   }
   echo '<div class="row" >';
   while($row = $result -> fetch_assoc()){
     $image= file_get_contents("html/img.html");
     $utvonal = "images/".$row['fajlhelye']."/".$row['fajlnev'];
     $image = str_replace("::kepforras::", $utvonal, $image);
     $image = str_replace("::kepleiras::", $row['leiras'], $image);
     echo $image;
   }
   echo '</div>';
}
print_html("html/footer.html");


